from django.contrib import admin
from .models import Room, Message

admin.site.register(Room)
admin.site.register(Message)